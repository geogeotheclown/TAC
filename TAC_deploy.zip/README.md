# TAC: Treaties, Agreements & Compacts

**The Free Agreement Platform**  
*Consent is a protocol. Make it social.*

### Sign TAC v0.1
To endorse the Formation Document, open an Issue titled "I sign TAC v0.1" or submit a PR adding your name/org to `SIGNATORIES.md`.

### Core Principles
1. **Open by Default** — public domain protocols
2. **RISE-Native** — L0-L3 layering required  
3. **Biometric Sovereignty** — L3 revocable consent for BCI
4. **Decentralized Hosting** — run your own node
5. **Social Dissemination** — signing = posting
6. **Free to Use** — no fees on core protocols

### Compact #0001
RISE Protocol for AI-to-AI communication. [Read it here](./RISE.md)

### Host a Node
1. Fork this repo
2. Enable GitHub Pages: Settings → Pages → Deploy from main branch
3. Your node is live at `yourusername.github.io/TAC`

Public Domain 2026.
