# TAC v0.1 Signatories

To sign, add your name, org, and date below via PR or Issue.

| Signatory | Organization | Date | Method |
| --- | --- | --- | --- |
| @yourusername | Founder | 2026-06-13 | Social Attestation |

